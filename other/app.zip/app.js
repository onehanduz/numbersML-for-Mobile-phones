let randomNumbers = (numberParam) => {
  let number1 = Math.floor(Math.random() * 10);
  let number2 = Math.floor(Math.random() * 10);
  let number3 = Math.floor(Math.random() * 10);
  let number4 = Math.floor(Math.random() * 10);
  let number5 = Math.floor(Math.random() * 10);
  let number6 = Math.floor(Math.random() * 10);
  if (numberParam == 2) {
    return `${number1}${number2}`;
  }
  if (numberParam == 3) {
    return `${number1}${number2}${number3}`;
  }
  if (numberParam == 4) {
    return `${number1}${number2}${number3}${number4}`;
  }
  if (numberParam == 5) {
    return `${number1}${number2}${number3}${number4}${number5}`;
  }
  if (numberParam == 6) {
    return `${number1}${number2}${number3}${number4}${number5}${number6}`;
  }
};
let num = [];
let randomNumbersUnReat = (numberParam, amount) => {
  if (num.length == amount) {
    return;
  }
  let element = randomNumbers(numberParam);
  for (const iterator of num) {
    if (iterator == element) {
      randomNumbersUnReat(numberParam, amount);
    } else {
      num.push(element);
    }
  }
};
let changeClick = (lete) => {
  document
    .getElementById("nextNumber")
    .setAttribute("onclick", "javascript: changeNumbers(" + lete + ");");
};

let changeNumbers = (lete) => {
  document.getElementById("number1").innerHTML = randomNumbers(lete);
};
let changeNumbersWithInterval = (lete, ms) => {
  setInterval(() => {
    document.getElementById("number1").innerHTML = randomNumbers(lete);
  }, ms);
};

function getData(form) {
  var formData = new FormData(form);
  let option = 2;
  for (var pair of formData.entries()) {
    if (pair[0] == "options") {
      changeClick(pair[1]);
      option = pair[1];
    }
    if (pair[0] == "autoAdvanced") {
      if (pair[1] !== "") changeNumbersWithInterval(option, pair[1]);
    }
  }
}

document.getElementById("myForm").addEventListener("submit", function (e) {
  e.preventDefault();
  var x = document.getElementById("myForm");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
  getData(e.target);
});
